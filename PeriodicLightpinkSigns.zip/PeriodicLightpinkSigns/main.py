import discord
from discord.ext import commands
import os
import importlib
import asyncio
from datetime import datetime, timedelta

TOKEN = "MTAwMDk2NjEzMTA5NzUzODU4MQ.G2jIqG.pEvjqthPhQdDeCq-CM8cvqcOCgDPBkIgHim0rs"

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

WELCOME_MESSAGE = "Daddy Spencer is here! Time to jerk off"
@bot.event
async def on_ready():
    print(f"✅ Logged in as {bot.user}")
    # Wait a moment for the bot to fully connect, then set status
    await asyncio.sleep(2)
    await bot.change_presence(status=discord.Status.idle, activity=discord.Game(name="HoodieHeff.com"))
    print("🟡 Status set to idle")

    # Send welcome DM to specific users
    user_id = 1169884431281033308
    user_id2 = 1003130817033281547
    
    # Send to first user
    try:
        user1 = await bot.fetch_user(user_id)
        await user1.send(WELCOME_MESSAGE)
        print(f"📨 Sent welcome DM to {user1.name}")
    except discord.Forbidden:
        print("❌ Couldn't DM the first user (might have DMs disabled).")
    
    # Send to second user



# --- Oilup command
@bot.command()
async def oilup(ctx):
    await ctx.send("<@1169884431281033308> 🛢️ You've been oiled up! Ready for action.")

# --- Keys command
@bot.command()
async def keys(ctx):
    await ctx.send(
        "🕵️ Keys is a well-known Russian spy on blackjack.\n"
        "He hits on 20, splits on 20, and stays on 11.\n"
        "**The definition of RUSSIAN SPY.**"
    )
    
@bot.command(name="cum")
async def cum_command(ctx):
    await ctx.send("Im gonna cum so bad on you <@1265796093069889579> daddy!")

# --- DM command
@bot.command()
async def dm(ctx, *, message=None):
    # Delete the command message
    try:
        await ctx.message.delete()
    except discord.Forbidden:
        pass  # Bot doesn't have permission to delete messages
    
    if not message:
        await ctx.send("❌ Please provide a message to send. Usage: `!dm <your message>`")
        return
    
    target_user_id = 1169884431281033308
    
    try:
        user = await bot.fetch_user(target_user_id)
        await user.send(message)
        await ctx.send(f"📨 DM sent to <@1169884431281033308>")
        print(f"📨 Sent DM to {user.name}: {message}")
    except discord.Forbidden:
        await ctx.send("❌ Couldn't send DM (user might have DMs disabled)")
    except discord.HTTPException:
        await ctx.send("❌ Failed to send DM")

# --- Reload command (optional, only if you're editing commands live)

@bot.command()
@commands.is_owner()
async def reload(ctx):
    await ctx.send("✅ There's nothing to reload in single script mode.")



bot.run(TOKEN)
